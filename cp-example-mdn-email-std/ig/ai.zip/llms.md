# ans.hl7v2.fr.trans-cda-mss#1.1.3: Volet Transmission au LPS de documents CDA provenant d'un courriel MSSanté

## Pages

* [Accueil](index.md)
* [Téléchargements](download.md)
* [Lien entre l'en-tête CDA et les métadonnées XDS](lien-entete-cda-meta-xds.md)
* [Table MetaDMP/MSS](meta-dmp-mss.md)
* [Volume 2 : Détail des transactions](volume2.md)
* [Volume 1 : Etude fonctionnelle](volume1.md)
* [Codes erreurs de traitement du message HL7 MDM](error-codes.md)
* [Artifacts Summary](artifacts.md)
* [Structure d'un message de notification format courriel standard](struct-email-standard.md)
* [Structure du MDN (MSSanté)](struct-msg-mdn.md)
* [Glossaire](glossaire.md)
* [Test](testplan.md)
* [Historique des versions](change-log.md)
* [Exemples de messages](exemples.md)
* [Documents de référence](doc-ref.md)

## Resources

### ImplementationGuides

* [Volet Transmission au LPS de documents CDA provenant d'un courriel MSSanté](index.md)
